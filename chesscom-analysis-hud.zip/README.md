
# Chess.com Analysis HUD (Local Engine)

This Chrome/Edge/Brave extension shows a mini HUD on chess.com **analysis pages** and can analyze the current position **locally** using a user-supplied Stockfish WASM build.

## What it does
- Detects board state on chess.com Analysis/Game Review pages, renders a mini-board, and shows the FEN.
- When you click **Analyze (local)** on Analysis pages, it runs Stockfish (if present) and shows the top N lines (MultiPV).
- A toolbar popup lets you paste any FEN and analyze it off-site.

## Fair Play
The engine button is disabled on live play pages. Please use analysis responsibly and avoid engine assistance during rated games.

## Install
1. Download and unzip this folder.
2. Go to `chrome://extensions` → enable **Developer mode** → **Load unpacked** → select the folder.
3. (Engine) Download a Stockfish WASM worker (`stockfish.js` + `stockfish.wasm`). Place **stockfish.js** (and the accompanying `.wasm` if required by that build) into this extension folder, replacing the placeholder. The code loads it as a Web Worker via `chrome.runtime.getURL('stockfish.js')`.
4. Open a chess.com Analysis page and click **Analyze (local)** in the HUD. Or click the extension icon and paste a FEN in the popup.

## Notes
- MultiPV defaults to 3; adjust depth/time in the popup or modify the code.
- If you see "Engine unavailable", the worker didn't load. Make sure the file is named exactly `stockfish.js` and that any required `.wasm` is in the same folder (build-dependent).
