// engine.js - wrapper around user-supplied Stockfish WASM worker (stockfish.js)
(function(){
  const Engine = {
    _worker: null,
    _ready: false,
    _queue: [],
    _listeners: new Set(),
  };

  function initWorker() {
    if (Engine._worker) return;
    try {
      const url = chrome.runtime.getURL('stockfish.js'); // user must provide this file
      const w = new Worker(url);
      Engine._worker = w;
      w.onmessage = (e) => {
        const line = (e.data || '').toString();
        // notify listeners
        Engine._listeners.forEach(fn => { try { fn(line); } catch(_){} });
        if (line.startsWith('uciok')) Engine._ready = true;
      };
      w.postMessage('uci');
      w.postMessage('setoption name MultiPV value 3');
      w.postMessage('isready');
    } catch (e) {
      console.warn('[Analysis HUD] Stockfish worker failed to start. Place stockfish.js next to engine.js.', e);
      throw e;
    }
  }

  function parseInfo(lines) {
    // Extract best MultiPV lines
    const out = {};
    for (const s of lines) {
      if (!s.includes(' multipv ')) continue;
      // info depth 14 seldepth 21 multipv 1 score cp 34 pv e4 e5 Nf3 ...
      const m = s.match(/multipv\s+(\d+).*?score\s+(cp|mate)\s+(-?\d+).*?pv\s+([^\r\n]+)/);
      const bm = s.match(/\spv\s+([^\r\n]+)/);
      const mv = m ? parseInt(m[1],10) : null;
      if (mv) {
        let evalStr = '';
        if (m) {
          if (m[2]==='mate') evalStr = `#${m[3]}`;
          else evalStr = (parseInt(m[3],10)/100).toFixed(2);
        }
        out[mv] = { id: mv, eval: evalStr, pv: m ? m[4] : (bm?bm[1]:'') };
      }
    }
    // also try "bestmove" for primary move name
    return Object.values(out).sort((a,b)=>a.id-b.id);
  }

  async function analyzeFEN(fen, {depth=14, multipv=3, movetime=0}={}) {
    initWorker();
    if (!Engine._worker) throw new Error('Worker not available');
    Engine._ready = false;
    const collected = [];
    const listener = (line) => { collected.push(line); };
    Engine._listeners.add(listener);

    Engine._worker.postMessage('ucinewgame');
    Engine._worker.postMessage(`setoption name MultiPV value ${multipv}`);
    Engine._worker.postMessage(`position fen ${fen}`);
    if (movetime && movetime>0) Engine._worker.postMessage(`go movetime ${movetime}`);
    else Engine._worker.postMessage(`go depth ${depth}`);

    // wait a bit for results
    const wait = (ms)=>new Promise(r=>setTimeout(r,ms));
    await wait(Math.max(movetime||0, 2500) + 300); // ensure some info lines arrive

    // try to stop if still running
    try { Engine._worker.postMessage('stop'); } catch(_){}

    Engine._listeners.delete(listener);
    return parseInfo(collected);
  }

  window.AnalysisEngine = { analyzeFEN };
})();