// Placeholder. Replace this file with a Stockfish WASM build (e.g., stockfish.js + stockfish.wasm).
self.onmessage = (e)=>postMessage('uciok');
