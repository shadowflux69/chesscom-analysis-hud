// content.js - analysis-only overlay + FEN + optional engine suggestions
(function() {
  const PIECE_TO_UNICODE = {
    'P': '♙','N': '♘','B': '♗','R': '♖','Q': '♕','K': '♔',
    'p': '♟','n': '♞','b': '♝','r': '♜','q': '♛','k': '♚',
  };
  const files = ['a','b','c','d','e','f','g','h'];

  // Only allow engine analysis on analysis pages (not live play)
  function isAnalysisPage() {
    const path = location.pathname.toLowerCase();
    return path.includes('/analysis') || path.includes('/analysis/game') || path.includes('/game/review');
  }

  function parsePieceFromClasses(el) {
    const classes = (el.className || '').toString().split(/\s+/);
    // find piece code anywhere (wq, bk, etc.)
    const pcode = classes.find(c => /^[wb][prnbqk]$/.test(c));
    const sqClass = classes.find(c => /^square-\d+$/.test(c));
    if (!pcode || !sqClass) return null;
    const sqNum = sqClass.replace('square-','');
    const isWhite = pcode[0]==='w';
    const type = pcode[1]; // p,r,n,b,q,k
    let letter = type.toUpperCase();
    if (!isWhite) letter = letter.toLowerCase();

    // chess.com numbering: square-11 .. square-88 (rank,file) top->bottom ranks 1..8
    const rank = parseInt(sqNum[0], 10);
    const file = parseInt(sqNum[1], 10);
    if (!(rank>=1 && rank<=8 && file>=1 && file<=8)) return null;

    const row = rank - 1;   // 0..7 top->bottom
    const col = file - 1;   // 0..7 left->right
    return { letter, row, col };
  }

  function buildMatrix() {
    const matrix = Array.from({length:8}, () => Array(8).fill(null));
    document.querySelectorAll('.piece').forEach(el => {
      const p = parsePieceFromClasses(el);
      if (!p) return;
      matrix[p.row][p.col] = p.letter;
    });
    return matrix;
  }

  function matrixToFEN(matrix) {
    const rows = [];
    for (let r=0; r<8; r++) {
      let s='', empty=0;
      for (let c=0; c<8; c++) {
        const cell = matrix[r][c];
        if (!cell) empty++;
        else { if (empty){s+=empty; empty=0;} s+=cell; }
      }
      if (empty) s+=empty;
      rows.push(s);
    }
    // unknown: active color/castling/ep/clock -> placeholders
    return rows.join('/') + ' - - - 0 1';
  }

  function ensureHUD() {
    if (document.getElementById('ccmhud-root')) return;
    const root = document.createElement('div');
    root.id = 'ccmhud-root';
    const card = document.createElement('div');
    card.className = 'ccmhud-card';
    const header = document.createElement('div');
    header.className = 'ccmhud-row';
    header.innerHTML = `<span class="ccmhud-badge">${isAnalysisPage() ? 'Analysis page' : 'Live page (engine off)'}</span>`;

    const board = document.createElement('div');
    board.id = 'ccmhud-board';
    for (let r=0;r<8;r++){
      for (let c=0;c<8;c++){
        const sq = document.createElement('div');
        sq.className = 'ccmhud-square ' + (((r+c)%2===0)?'ccmhud-light':'ccmhud-dark');
        board.appendChild(sq);
      }
    }

    const row = document.createElement('div');
    row.className = 'ccmhud-row';
    const btnScan = document.createElement('button');
    btnScan.className = 'ccmhud-btn'; btnScan.textContent = 'Rescan';
    btnScan.addEventListener('click', scanNow);

    const btnAnalyze = document.createElement('button');
    btnAnalyze.className = 'ccmhud-btn'; btnAnalyze.textContent = 'Analyze (local)';
    btnAnalyze.addEventListener('click', analyzeNow);

    row.appendChild(btnScan);
    row.appendChild(btnAnalyze);

    const fenEl = document.createElement('div');
    fenEl.id = 'ccmhud-fen'; fenEl.textContent = 'FEN: (waiting…)';

    const linesEl = document.createElement('div');
    linesEl.id = 'ccmhud-lines';

    card.appendChild(header);
    card.appendChild(board);
    card.appendChild(row);
    card.appendChild(fenEl);
    card.appendChild(linesEl);
    root.appendChild(card);
    document.body.appendChild(root);
  }

  function renderBoard(matrix) {
    const squares = document.querySelectorAll('#ccmhud-board .ccmhud-square');
    for (let r=0;r<8;r++){
      for (let c=0;c<8;c++){
        const el = squares[r*8+c];
        const p = matrix[r][c];
        el.textContent = p ? (PIECE_TO_UNICODE[p]||'?') : '';
      }
    }
  }

  function scanNow() {
    try {
      const m = buildMatrix();
      renderBoard(m);
      document.getElementById('ccmhud-fen').textContent = 'FEN: ' + matrixToFEN(m);
    } catch (e) {
      console.warn('[Analysis HUD] scan error', e);
    }
  }

  async function analyzeNow() {
    if (!isAnalysisPage()) {
      alert('Engine is disabled on live play pages. Open the Analysis board or use the popup to paste FEN.');
      return;
    }
    try {
      const m = buildMatrix();
      const fen = matrixToFEN(m);
      document.getElementById('ccmhud-fen').textContent = 'FEN: ' + fen;
      document.getElementById('ccmhud-lines').textContent = 'Engine: thinking…';
      const lines = await window.AnalysisEngine.analyzeFEN(fen, { depth: 14, multipv: 3, movetime: 2500 });
      document.getElementById('ccmhud-lines').textContent = lines.map(l => `#${l.id}  ${l.move}  eval ${l.eval}  pv ${l.pv}`).join('\n');
    } catch (e) {
      document.getElementById('ccmhud-lines').textContent = 'Engine unavailable. Place stockfish.js in the extension folder (see README).';
      console.warn('[Analysis HUD] analyze error', e);
    }
  }

  function start() {
    ensureHUD();
    const obs = new MutationObserver(() => {
      clearTimeout(window.__ahud_t);
      window.__ahud_t = setTimeout(scanNow, 120);
    });
    obs.observe(document.body, {subtree:true, childList:true, attributes:true});
    setTimeout(scanNow, 600);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();