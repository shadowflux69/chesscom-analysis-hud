
document.getElementById('run').addEventListener('click', async () => {
  const fen = document.getElementById('fen').value.trim();
  const depth = parseInt(document.getElementById('depth').value,10)||16;
  const multipv = parseInt(document.getElementById('multipv').value,10)||3;
  const movetime = parseInt(document.getElementById('movetime').value,10)||0;
  const out = document.getElementById('lines');
  out.textContent = 'thinking…';
  try {
    const lines = await window.AnalysisEngine.analyzeFEN(fen, { depth, multipv, movetime });
    out.textContent = lines.map(l => `#${l.id}  eval ${l.eval}  pv ${l.pv}`).join('\n');
  } catch (e) {
    out.textContent = 'Engine unavailable. Ensure stockfish.js is placed in the extension folder.';
    console.warn(e);
  }
});
